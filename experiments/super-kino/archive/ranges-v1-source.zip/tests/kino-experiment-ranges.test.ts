import assert from "node:assert/strict";
import { test } from "node:test";
import { buildRangePortfolio, buildRangeTargets, rangeLoss } from "../lib/kino-experiment-ranges.ts";
import { buildV2Portfolio, diversityPenalty } from "../lib/kino-experiment-v2.ts";
import { validateExperimentPortfolio } from "../lib/kino-experiment-strategies.ts";
import type { KinoDraw } from "../lib/super-kino.ts";

const draw = (numbers: number[]): KinoDraw => ({ date: "2026-10-01", numbers, source: "https://example.com/" });
const concentrated = [draw(Array.from({ length: 20 }, (_, i) => i + 1))];
const distributed = [draw(Array.from({ length: 20 }, (_, i) => i * 4 + 1))];
const quotas = (tickets: number[][]) => {
  const result = Array<number>(85).fill(0);
  tickets.flat().forEach(n => { result[n]++; });
  return result;
};

test("range candidates preserve quotas, uniqueness, diversity ceiling and improve their frozen objective", () => {
  for (const seed of ["ranges:0", "ranges:1", "ranges:2"]) {
    const baseline = buildV2Portfolio("balanced-diverse", seed);
    const result = buildRangePortfolio(seed, concentrated);
    validateExperimentPortfolio(result);
    assert.deepEqual(quotas(result), quotas(baseline));
    assert.equal(quotas(result).filter(n => n === 23).length, 16);
    assert.equal(quotas(result).filter(n => n === 24).length, 68);
    assert.ok(diversityPenalty(result) <= diversityPenalty(baseline) * 1.05);
    const targets = buildRangeTargets(seed, concentrated);
    assert.ok(rangeLoss(result, targets) < rangeLoss(baseline, targets));
  }
});

test("ranges are deterministic, training-sensitive, and category-only", () => {
  const result = buildRangePortfolio("repeat", concentrated);
  assert.deepEqual(result, buildRangePortfolio("repeat", concentrated));
  assert.notDeepEqual(result, buildRangePortfolio("repeat", distributed));
  const sameCategories = [draw(distributed[0]!.numbers.map(n => n + 1))];
  assert.deepEqual(buildRangeTargets("identity", distributed), buildRangeTargets("identity", sameCategories));
  assert.deepEqual(buildRangePortfolio("identity", distributed), buildRangePortfolio("identity", sameCategories));
  const training = [...concentrated, ...distributed];
  assert.deepEqual(buildRangeTargets("order", training), buildRangeTargets("order", [...training].reverse()));
});

test("targets normalize each bin and give the four-number final bin appropriate support", () => {
  const targets = buildRangeTargets("bins", distributed);
  assert.equal(targets.length, 9);
  targets.forEach(row => {
    assert.equal(row.length, 11);
    assert.equal(row.reduce((sum, p) => sum + p, 0), 1);
  });
  assert.ok(targets[8]!.slice(5).every(p => p === 0));
  const mean = (row: number[]) => row.reduce((sum, p, n) => sum + p * n, 0);
  assert.ok(mean(targets[8]!) < mean(targets[0]!));
});

test("training validation rejects empty, duplicate, short and out-of-domain histories", () => {
  assert.throws(() => buildRangePortfolio("invalid", []), /vacío/);
  for (const numbers of [Array(20).fill(1), [1, 2], Array.from({ length: 20 }, (_, i) => i + 70)]) {
    assert.throws(() => buildRangeTargets("invalid", [draw(numbers)]), /20 números únicos/);
  }
  assert.throws(() => rangeLoss([], buildRangeTargets("valid", concentrated)), /vacía/);
  for (const weight of [-0.1, 1.1, NaN]) {
    assert.throws(() => buildRangeTargets("invalid", concentrated, weight), /peso histórico/);
  }
});

test("uniform ablation ignores history profiles but uses the identical optimizer", () => {
  assert.deepEqual(buildRangeTargets("ablation", concentrated, 0), buildRangeTargets("ablation", distributed, 0));
  const result = buildRangePortfolio("ablation", concentrated, 0);
  assert.deepEqual(result, buildRangePortfolio("ablation", distributed, 0));
  const base = buildV2Portfolio("balanced-diverse", "ablation");
  assert.deepEqual(quotas(result), quotas(base));
  assert.ok(diversityPenalty(result) <= diversityPenalty(base) * 1.05);
  const targets = buildRangeTargets("ablation", concentrated, 0);
  assert.ok(rangeLoss(result, targets) <= rangeLoss(base, targets));
});
