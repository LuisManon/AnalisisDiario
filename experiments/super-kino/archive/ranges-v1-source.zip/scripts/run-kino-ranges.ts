/** Offline range ablation. Validation only, no production imports into the app. */
import fs from "node:fs";
import path from "node:path";
import {createHash} from "node:crypto";
import {prepareKinoExperimentData,priorDraws} from "../lib/kino-experiment-data.ts";
import {compilePortfolio,summarizeEvaluations} from "../lib/kino-experiment-metrics.ts";
import {buildV2Portfolio,diversityPenalty} from "../lib/kino-experiment-v2.ts";
import {buildRangePortfolio,buildRangeTargets,rangeLoss} from "../lib/kino-experiment-ranges.ts";
import type {KinoDraw} from "../lib/super-kino.ts";

const args=new Map(process.argv.slice(2).map(arg=>{const [key,...parts]=arg.replace(/^--/,"").split("=");return [key,parts.join("=")];}));
for(const key of args.keys())if(!["cutoff","draws","replicates","run-id"].includes(key))throw new Error(`Unknown option ${key}; validation only`);
const cutoff=args.get("cutoff"),runId=args.get("run-id");
if(!cutoff)throw new Error("Explicit cutoff required");
if(!runId||!/^[a-z0-9-]{1,80}$/.test(runId))throw new Error("Safe run-id required");
const drawsPerReplicate=Number(args.get("draws")??5000),replicates=Number(args.get("replicates")??12);
if(!Number.isInteger(drawsPerReplicate)||drawsPerReplicate<100||drawsPerReplicate>100000)throw new Error("draws must be integer100..100000");
if(!Number.isInteger(replicates)||replicates<2||replicates>50)throw new Error("replicates must be integer2..50");
const output=path.resolve("experiments/super-kino",`${runId}.json`);
if(fs.existsSync(output))throw new Error("Run exists; do not overwrite");
const data=prepareKinoExperimentData(JSON.parse(fs.readFileSync("data/super-kino-results.json","utf8")),{cutoff,warmup:30,validationCount:10});
const sources=["scripts/run-kino-ranges.ts","lib/kino-experiment-ranges.ts","lib/kino-experiment-v2.ts","lib/kino-experiment-strategies.ts","lib/kino-experiment-data.ts","lib/kino-experiment-metrics.ts","lib/super-kino-v133.ts","lib/super-kino.ts"];
const sha=(text:string)=>createHash("sha256").update(text).digest("hex");
const codeSha256=sha(sources.map(file=>`${file}\n${fs.readFileSync(file,"utf8")}`).join("\n"));
const modes=["uniform","diverse","ranges-uniform","ranges-history"] as const;
function rng(seed:string){let state=2166136261;for(const char of seed)state=Math.imul(state^char.charCodeAt(0),16777619);return()=>{state=(state+0x6d2b79f5)>>>0;let v=Math.imul(state^(state>>>15),state|1);v^=v+Math.imul(v^(v>>>7),v|61);return((v^(v>>>14))>>>0)/4294967296;};}
function draw(random:()=>number){const pool=Array.from({length:84},(_,i)=>i+1);for(let i=83;i>0;i--){const j=Math.floor(random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}return pool.slice(0,20);}
function portfolio(mode:typeof modes[number],seed:string,training:KinoDraw[]){return mode==="uniform"?buildV2Portfolio("uniform",seed):mode==="diverse"?buildV2Portfolio("balanced-diverse",seed):buildRangePortfolio(seed,training,mode==="ranges-history"?.5:0);}
const historical=[];
for(const target of data.validation){
  const training=priorDraws(data,target.date).slice(-30),seed=`kino-lab-ranges-v1/validation/historical/${target.date}`;
  const methods:Record<string,unknown>={};
  for(const mode of modes){const tickets=portfolio(mode,seed,training);methods[mode]={seed,diversity:diversityPenalty(tickets),evaluation:compilePortfolio(tickets)(target.numbers)};}
  historical.push({date:target.date,trainingDates:training.map(row=>row.date),methods});
}
type Summary=ReturnType<typeof summarizeEvaluations>;
type Result={replicate:number;seed:string;drawSeed:string;methods:Record<string,{summary:Summary;diversity:number;historicalRangeLoss:number;uniformRangeLoss:number;portfolioSha256:string}>};
const synthetic:Result[]=[];
for(let replicate=0;replicate<replicates;replicate++){
  const seed=`kino-lab-ranges-v1/validation/portfolio/${replicate}`,drawSeed=`kino-lab-ranges-v1/validation/draws/${replicate}`;
  const random=rng(drawSeed),scenarios=Array.from({length:drawsPerReplicate},()=>draw(random));
  const targets=buildRangeTargets(seed,data.warmup,.5),uniformTargets=buildRangeTargets(seed,data.warmup,0);
  const methods:Result["methods"]={};
  for(const mode of modes){
    process.stderr.write(`Ranges replicate${replicate+1}/${replicates} ${mode}\n`);
    const tickets=portfolio(mode,seed,data.warmup),evaluate=compilePortfolio(tickets);
    methods[mode]={summary:summarizeEvaluations(scenarios.map(winning=>evaluate(winning))),diversity:diversityPenalty(tickets),historicalRangeLoss:rangeLoss(tickets,targets),uniformRangeLoss:rangeLoss(tickets,uniformTargets),portfolioSha256:sha(JSON.stringify(tickets))};
  }
  synthetic.push({replicate,seed,drawSeed,methods});
}
const mean=(values:number[])=>values.reduce((sum,value)=>sum+value,0)/values.length;
const summaries=Object.fromEntries(modes.map(mode=>[mode,Object.fromEntries((["meanHits","meanMax","atLeast6Rate","atLeast7Rate","atLeast8Rate"] as const).map(key=>[key,mean(synthetic.map(row=>row.methods[mode].summary[key]))]))]));
const references=["diverse","ranges-uniform"];
const comparisons=Object.fromEntries(references.map(reference=>{
  const differences=synthetic.map(row=>row.methods["ranges-history"].summary.atLeast7Rate-row.methods[reference].summary.atLeast7Rate),random=rng(`kino-lab-ranges-v1/bootstrap/${reference}`);
  const bootstrap=Array.from({length:10000},()=>mean(Array.from({length:replicates},()=>differences[Math.floor(random()*replicates)]))).sort((a,b)=>a-b);
  const quantile=(p:number)=>bootstrap[Math.floor(p*(bootstrap.length-1))];
  return [reference,{replicateDifferences:differences,meanDifference:mean(differences),interval:[quantile(.05/(2*references.length)),quantile(1-.05/(2*references.length))],leaveOneOutMinimum:Math.min(...differences.map((_,i)=>mean(differences.filter((__,j)=>i!==j))))}];
}));
const qualifies=references.every(reference=>comparisons[reference].meanDifference>=.01&&comparisons[reference].interval[0]>0&&comparisons[reference].leaveOneOutMinimum>0)
  &&mean(synthetic.map(row=>row.methods["ranges-history"].summary.atLeast8Rate-row.methods.diverse.summary.atLeast8Rate))>=-.002;
const report={protocol:{version:"kino-lab-ranges-v1",phase:"validation-only",cutoff,node:process.version,datasetSha256:data.sha256,codeSha256,lockfileSha256:sha(fs.readFileSync("package-lock.json","utf8")),sources,metadata:data.metadata,partitions:data.dates,modes,drawsPerReplicate,replicates,syntheticTrainingDates:data.warmup.map(row=>row.date),bins:"1-10,11-20,...,71-80,81-84; final bin width4",historicalWeight:.5,construction:"Fixed range-profile target, 10,000 reciprocal swaps, same diverse base seed, exact number exposure preserved, diversity penalty cap1.05x base",primary:"atLeast7Rate per200-ticket portfolio",criterion:"Mean advantage>=1percentage point versus diverse and ranges-uniform, Bonferroni2-comparison bootstrap lower bounds>0, positive leave-one-out means, mean8+ deterioration versus diverse<=0.2percentage point",uncertainty:"10,000 bootstrap resamples of whole seed replicates; approximate with12seeds, exploratory",historical:"Prior30only, reconstructed comparisons on previously inspected validation dates",activation:"None; no historical or synthetic holdout evaluated"},historical,synthetic,summaries,comparisons,qualifiesForFurtherTesting:qualifies};
fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,JSON.stringify(report,null,2)+"\n",{flag:"wx"});console.log(`Saved ${output}`);
