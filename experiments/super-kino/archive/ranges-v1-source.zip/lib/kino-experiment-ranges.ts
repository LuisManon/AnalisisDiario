import { buildV2Portfolio, diversityPenalty } from "./kino-experiment-v2.ts";
import { validateExperimentPortfolio } from "./kino-experiment-strategies.ts";
import type { KinoDraw } from "./super-kino.ts";

/** Offline, frozen construction objective. No evaluated winning draw is consumed. */
export const RANGE_VERSION = "range-coverage-v1";
export const RANGE_PROFILE_COUNT = 4096;
export const RANGE_SWAP_ATTEMPTS = 10_000;
export type RangeTargets = number[][];
const bin = (number: number) => Math.floor((number - 1) / 10);
const pairKey = (a: number, b: number) => Math.min(a, b) * 85 + Math.max(a, b);
const overlapPenalty = (count: number) => 100 * Math.max(0, count - 4) ** 2;

function randomFor(seed: string) {
  let state = 2166136261;
  for (const character of seed) state = Math.imul(state ^ character.charCodeAt(0), 16777619);
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let value = Math.imul(state ^ (state >>> 15), state | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function profile(categories: readonly number[], random: () => number) {
  const pool = [...categories];
  const counts = Array<number>(9).fill(0);
  for (let i = 0; i < 10; i++) {
    const selected = i + Math.floor(random() * (pool.length - i));
    [pool[i], pool[selected]] = [pool[selected]!, pool[i]!];
    counts[pool[i]!]++;
  }
  return counts;
}

/** Histograms of each bin's ticket count (0..10), normalized to probabilities.
 * Default: half uniform 10/84, half 10/20 subsamples of historical category
 * profiles. Weight 0 is the uniform-profile ablation, same optimizer/budget.
 * The 81..84 bin has four population slots, never the weight of a full decena.
 * Caller MUST supply only training draws preceding the evaluation date.
 */
export function buildRangeTargets(seed: string, training: readonly KinoDraw[], historicalWeight = 0.5): RangeTargets {
  if (!Number.isFinite(historicalWeight) || historicalWeight < 0 || historicalWeight > 1) {
    throw new Error("El peso histórico debe estar entre 0 y 1.");
  }
  if (!training.length) throw new Error("El entrenamiento de rangos no puede estar vacío.");
  for (const draw of training) {
    if (draw.numbers.length !== 20 || new Set(draw.numbers).size !== 20 ||
        draw.numbers.some(n => !Number.isInteger(n) || n < 1 || n > 84)) {
      throw new Error("Entrenamiento inválido: se requieren 20 números únicos entre 1 y 84.");
    }
  }
  // Sort and retain ONLY category multiplicities: identities within a bin have
  // no effect, and input ordering cannot influence the reproducible experiment.
  const histories = training.map(draw => draw.numbers.map(bin).sort((a, b) => a - b))
    .sort((a, b) => a.join(",").localeCompare(b.join(",")));
  const universe = Array.from({ length: 84 }, (_, i) => bin(i + 1));
  const targets = Array.from({ length: 9 }, () => Array<number>(11).fill(0));
  const random = randomFor(`${RANGE_VERSION}:targets:${seed}`);
  for (let i = 0; i < RANGE_PROFILE_COUNT; i++) {
    const categories = i < Math.round(RANGE_PROFILE_COUNT * (1 - historicalWeight)) ? universe
      : histories[Math.floor(random() * histories.length)]!;
    profile(categories, random).forEach((count, position) => { targets[position]![count]++; });
  }
  return targets.map(row => row.map(count => count / RANGE_PROFILE_COUNT));
}

function ticketProfile(ticket: readonly number[]) {
  const result = Array<number>(9).fill(0);
  ticket.forEach(number => { result[bin(number)]++; });
  return result;
}

export function rangeLoss(tickets: readonly (readonly number[])[], targets: RangeTargets) {
  if (!tickets.length) throw new Error("La cartera no puede estar vacía.");
  const histogram = Array.from({ length: 9 }, () => Array<number>(11).fill(0));
  tickets.forEach(ticket => ticketProfile(ticket).forEach((count, position) => { histogram[position]![count]++; }));
  return histogram.reduce((sum, row, position) => sum + row.reduce((subtotal, count, n) =>
    subtotal + (count / tickets.length - targets[position]![n]!) ** 2, 0), 0);
}

export function buildRangePortfolio(seed: string, training: readonly KinoDraw[], historicalWeight = 0.5): number[][] {
  const targets = buildRangeTargets(seed, training, historicalWeight);
  const tickets = buildV2Portfolio("balanced-diverse", seed);
  let diversity = diversityPenalty(tickets);
  const ceiling = diversity * 1.05;
  const random = randomFor(`${RANGE_VERSION}:swaps:${seed}`);
  const membership = tickets.map(ticket => {
    const flags = new Uint8Array(85);
    ticket.forEach(number => { flags[number] = 1; });
    return flags;
  });
  const pairs = new Int32Array(85 * 85);
  tickets.forEach(ticket => ticket.forEach((a, i) => ticket.slice(i + 1).forEach(b => { pairs[pairKey(a, b)]++; })));
  const overlaps = tickets.map((ticket, i) => tickets.map((other, j) =>
    i === j ? 10 : ticket.filter(n => other.includes(n)).length));
  const profiles = tickets.map(ticketProfile);
  const histogram = Array.from({ length: 9 }, () => Array<number>(11).fill(0));
  profiles.forEach(row => row.forEach((count, position) => { histogram[position]![count]++; }));
  const seen = new Set(tickets.map(ticket => ticket.join(",")));
  for (let attempt = 0; attempt < RANGE_SWAP_ATTEMPTS; attempt++) {
    const a = Math.floor(random() * tickets.length), b = Math.floor(random() * tickets.length);
    const x = tickets[a]![Math.floor(random() * 10)]!, y = tickets[b]![Math.floor(random() * 10)]!;
    if (a === b || bin(x) === bin(y) || membership[a]![y] || membership[b]![x]) continue;
    const nextA = [...profiles[a]!], nextB = [...profiles[b]!];
    nextA[bin(x)]--; nextA[bin(y)]++; nextB[bin(y)]--; nextB[bin(x)]++;
    const changes = new Map<number, number>();
    const change = (key: number, delta: number) => changes.set(key, (changes.get(key) ?? 0) + delta);
    for (const position of [bin(x), bin(y)]) {
      change(position * 11 + profiles[a]![position]!, -1);
      change(position * 11 + profiles[b]![position]!, -1);
      change(position * 11 + nextA[position]!, 1);
      change(position * 11 + nextB[position]!, 1);
    }
    let lossDelta = 0;
    for (const [key, delta] of changes) {
      const position = Math.floor(key / 11), count = key % 11;
      const old = histogram[position]![count]! / 200 - targets[position]![count]!;
      lossDelta += (old + delta / 200) ** 2 - old ** 2;
    }
    if (lossDelta >= -1e-12) continue;
    const candidateA = tickets[a]!.map(n => n === x ? y : n).sort((m, n) => m - n);
    const candidateB = tickets[b]!.map(n => n === y ? x : n).sort((m, n) => m - n);
    const keyA = candidateA.join(","), keyB = candidateB.join(",");
    if (keyA === keyB || seen.has(keyA) || seen.has(keyB)) continue;
    const pairChanges = new Map<number, number>();
    const pairChange = (u: number, v: number, delta: number) => {
      const key = pairKey(u, v); pairChanges.set(key, (pairChanges.get(key) ?? 0) + delta);
    };
    for (const n of tickets[a]!) if (n !== x) { pairChange(x, n, -1); pairChange(y, n, 1); }
    for (const n of tickets[b]!) if (n !== y) { pairChange(y, n, -1); pairChange(x, n, 1); }
    let diversityDelta = 0;
    for (const [key, delta] of pairChanges) {
      const old = pairs[key]!, next = old + delta;
      diversityDelta += next * (next - 1) / 2 - old * (old - 1) / 2;
    }
    // Overlap between a and b is unchanged by exchanging exclusive numbers.
    for (let k = 0; k < tickets.length; k++) {
      if (k === a || k === b) continue;
      const shift = membership[k]![y]! - membership[k]![x]!;
      diversityDelta += overlapPenalty(overlaps[a]![k]! + shift) - overlapPenalty(overlaps[a]![k]!);
      diversityDelta += overlapPenalty(overlaps[b]![k]! - shift) - overlapPenalty(overlaps[b]![k]!);
    }
    if (diversity + diversityDelta > ceiling) continue;
    diversity += diversityDelta;
    for (const [key, delta] of pairChanges) pairs[key] += delta;
    for (const [key, delta] of changes) histogram[Math.floor(key / 11)]![key % 11] += delta;
    for (let k = 0; k < tickets.length; k++) {
      if (k === a || k === b) continue;
      const shift = membership[k]![y]! - membership[k]![x]!;
      overlaps[a]![k] = overlaps[k]![a] = overlaps[a]![k]! + shift;
      overlaps[b]![k] = overlaps[k]![b] = overlaps[b]![k]! - shift;
    }
    seen.delete(tickets[a]!.join(",")); seen.delete(tickets[b]!.join(","));
    seen.add(keyA); seen.add(keyB);
    tickets[a] = candidateA; tickets[b] = candidateB;
    profiles[a] = nextA; profiles[b] = nextB;
    membership[a]![x] = 0; membership[a]![y] = 1;
    membership[b]![y] = 0; membership[b]![x] = 1;
  }
  validateExperimentPortfolio(tickets);
  return tickets;
}
